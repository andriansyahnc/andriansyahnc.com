You can find documentation in the [wiki](https://github.com/mikey179/vfsStream/wiki).

Also you might want to check [vfsStream examples](https://github.com/mikey179/vfsStream-examples).


[![Build Status](https://secure.travis-ci.org/mikey179/vfsStream.png)](http://travis-ci.org/mikey179/vfsStream) [![Coverage Status](https://coveralls.io/repos/mikey179/vfsStream/badge.png?branch=master)](https://coveralls.io/r/mikey179/vfsStream?branch=master)

[![Latest Stable Version](https://poser.pugx.org/mikey179/vfsStream/version.png)](https://packagist.org/packages/mikey179/vfsStream) [![Latest Unstable Version](https://poser.pugx.org/mikey179/vfsStream/v/unstable.png)](//packagist.org/packages/mikey179/vfsStream)
