CHANGELOG for 0.2.x
===================
This changelog references the relevant changes (bug and security fixes) done in 0.2 minor versions.

* 0.2.3

  * bug #1 set_url_blacklist was not working properly (thanks to reporter)
