GastonJS for Webpage automation
================================
[![Build Status](https://travis-ci.org/jcalderonzumba/gastonjs.svg?branch=travis_ci)](https://travis-ci.org/jcalderonzumba/gastonjs)
[![Latest Stable Version](https://poser.pugx.org/jcalderonzumba/gastonjs/v/stable)](https://packagist.org/packages/jcalderonzumba/gastonjs)
[![Total Downloads](https://poser.pugx.org/jcalderonzumba/gastonjs/downloads)](https://packagist.org/packages/jcalderonzumba/gastonjs)


For full documentation go to [GastonJS doc](http://gastonjs.readthedocs.org/en/latest/)
