<?php
namespace Zumba\GastonJS\Exception;


/**
 * Class NoSuchWindowError
 * @package Zumba\GastonJS\Exception
 */
class NoSuchWindowError extends ClientError {
}
