<?php

define("DRUPAL_CONSOLE_CORE", "/vendor/drupal/console-core/");
define("DRUPAL_CONSOLE_LAUNCHER", "/vendor/drupal/console-launcher/");
define("DRUPAL_CONSOLE", "/vendor/drupal/console/");
define("DRUPAL_CONSOLE_LANGUAGE", "/vendor/drupal/console-%s/translations/");
