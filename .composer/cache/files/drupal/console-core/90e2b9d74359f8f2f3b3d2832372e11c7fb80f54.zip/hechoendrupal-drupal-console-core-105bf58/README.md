# Drupal Console Core

Drupal Console Core, this project contains commands and features to be shared across DrupalConsole projects.
